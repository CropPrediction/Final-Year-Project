package com.example.croppredictionapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CountryData extends AppCompatActivity {

    /*@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_country_data);
    }*/
    public static final String[] countryNames = {"India"};

    public static final String[] countryAreaCodes = { "91" };
}
